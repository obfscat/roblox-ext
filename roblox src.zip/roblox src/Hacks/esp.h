﻿#pragma once

#include "../renderer/W2S.h"
#include "../renderer/imgui/imgui.h"
#include "../options.h"
#include <algorithm>

inline void RenderESP(ImDrawList* drawList)
{
    auto localTeam = Globals::Roblox::LocalPlayer.Team();
    auto cameraPos = Memory->read<Vectors::Vector3>(Globals::Roblox::Camera.address + offsets::CameraPos);
    auto localCharacter = Globals::Roblox::LocalPlayer.Character();
    auto localHead = localCharacter.FindFirstChild("Head");
    auto localTorso = localCharacter.FindFirstChild("Torso");
    if (localTorso.address == 0)
        localTorso = localCharacter.FindFirstChild("UpperTorso");
    auto localHeadPos = localHead.Position();
    auto localTorsoPos = localTorso.Position();
    auto localTorsoPos2D = WorldToScreen(localTorsoPos);
    auto Dimensions = Memory->read<Vectors::Vector2>(Globals::Roblox::VisualEngine + offsets::Dimensions);

    ImFont* font = ImGui::GetFont();

    for (auto& player : Globals::Caches::CachedPlayerObjects)
    {
        if (player.address == Globals::Roblox::LocalPlayer.address)
            continue;

        if (player.Health <= 0)
            continue;

        if (player.Team.address == localTeam.address && Options::ESP::TeamCheck)
            continue;

        auto rigType = player.RigType;

        auto head = player.Head;

        RobloxInstance torso(0), rightLeg(0), leftLeg(0), rightArm(0), leftArm(0);
        if (rigType == 0) {
            torso = player.Torso;
            rightLeg = player.Right_Leg;
            leftLeg = player.Left_Leg;
            rightArm = player.Right_Arm;
            leftArm = player.Left_Arm;
        }
        else if (rigType == 1) {
            torso = player.Upper_Torso;
            rightLeg = player.Right_Foot;
            leftLeg = player.Left_Foot;
            rightArm = player.Right_Hand;
            leftArm = player.Left_Hand;
        }

        auto head3D = head.Position();
        auto torso3D = torso.Position();
        auto rLeg3D = rightLeg.Position();
        auto lLeg3D = leftLeg.Position();
        auto rArm3D = rightArm.Position();
        auto lArm3D = leftArm.Position();

        auto head2D = WorldToScreen(head3D);
        auto torso2D = WorldToScreen(torso3D);
        auto rLeg2D = WorldToScreen(rLeg3D);
        auto lLeg2D = WorldToScreen(lLeg3D);
        auto rArm2D = WorldToScreen(rArm3D);
        auto lArm2D = WorldToScreen(lArm3D);

        if (torso2D.x == -1 || torso2D.y == -1)
            continue;

        float distance = (localHeadPos - head3D).Magnitude();
        float camDistance = (cameraPos - head3D).Magnitude();
        float scale = std::clamp(1.0f / camDistance * 100.0f, 0.3f, 1.5f); 

        auto newHeadPos = WorldToScreen(head3D + Vectors::Vector3{ 0.f, 0.6f, 0.f }); 
        auto newHeadName = WorldToScreen(head3D + Vectors::Vector3{ 0.f, 1.2f, 0.f }); 
        auto newLeftLeg = WorldToScreen(lLeg3D - Vectors::Vector3{ 0.f, 0.8f, 0.f }); 
        auto newRightLeg = WorldToScreen(rLeg3D - Vectors::Vector3{ 1.8f, 0.0f, 0.f }); 
        auto newHeadPosHealth = WorldToScreen(head3D - Vectors::Vector3{ 1.5f, 0.f, 0.f }); 

        auto hrpCFrame = player.HumanoidRootPart.CFrame();
        Vectors::Vector3 rightVector = hrpCFrame.GetRightVector();

        float halfWidth = 1.3f; 

        Vectors::Vector3 leftWorld = torso3D - (rightVector * halfWidth);
        Vectors::Vector3 rightWorld = torso3D + (rightVector * halfWidth);

        auto left2D = WorldToScreen(leftWorld);
        auto right2D = WorldToScreen(rightWorld);

        ImVec2 topLeft(std::min<float>(left2D.x, right2D.x), newHeadPos.y);
        ImVec2 bottomRight(std::max<float>(left2D.x, right2D.x), newLeftLeg.y);
        int roundedDistance = static_cast<int>(std::round(distance));

        
        std::vector<ImVec2> points = {
            ImVec2(head2D.x, newHeadPos.y), 
            ImVec2(torso2D.x, torso2D.y),
            ImVec2(lLeg2D.x, newLeftLeg.y), 
            ImVec2(rLeg2D.x, newLeftLeg.y),
            ImVec2(left2D.x, torso2D.y), 
            ImVec2(right2D.x, torso2D.y)
        };

        float left = FLT_MAX, top = FLT_MAX;
        float right = -FLT_MAX, bottom = -FLT_MAX;

        for (const auto& pt : points)
        {
            if (pt.x == -1 || pt.y == -1)
                continue;

            left = std::min<float>(left, pt.x);
            right = std::max<float>(right, pt.x);
            top = std::min<float>(top, pt.y);
            bottom = std::max<float>(bottom, pt.y);
        }

        
        float boxWidth = right - left;
        float reduction = boxWidth * 0.15f;
        left += reduction;
        right -= reduction;

        ImColor	color = IM_COL32(
            static_cast<int>(Options::ESP::Color[0] * 255.f),
            static_cast<int>(Options::ESP::Color[1] * 255.f),
            static_cast<int>(Options::ESP::Color[2] * 255.f),
            255);

        ImColor	fillColor = IM_COL32(
            static_cast<int>(Options::ESP::FillColor[0] * 255.f),
            static_cast<int>(Options::ESP::FillColor[1] * 255.f),
            static_cast<int>(Options::ESP::FillColor[2] * 255.f),
            static_cast<int>(Options::ESP::FillColor[3] * 255.f)
        );

        if (Options::ESP::Box)
        {
            if (left < right && top < bottom)
            {
                drawList->AddRectFilled(ImVec2(left, top), ImVec2(right, bottom), fillColor);
                drawList->AddRect(ImVec2(left, top), ImVec2(right, bottom), IM_COL32(0, 0, 0, 200), 0, 0, 2.0f); 
                drawList->AddRect(ImVec2(left, top), ImVec2(right, bottom), color, 0, 0, 1.2f); 
            }
        }

        if (Options::ESP::Tracers)
        {
            switch (Options::ESP::TracersStart)
            {
            case 0: 
                drawList->AddLine(ImVec2(Dimensions.x / 2, Dimensions.y), ImVec2(head2D.x, head2D.y), IM_COL32(0, 0, 0, 200), 2.5f); // Thinner
                drawList->AddLine(ImVec2(Dimensions.x / 2, Dimensions.y), ImVec2(head2D.x, head2D.y), color, 1.5f); 
                break;
            case 1: 
                drawList->AddLine(ImVec2(Dimensions.x / 2, 0), ImVec2(head2D.x, head2D.y), IM_COL32(0, 0, 0, 200), 2.5f);
                drawList->AddLine(ImVec2(Dimensions.x / 2, 0), ImVec2(head2D.x, head2D.y), color, 1.5f);
                break;
            case 2: 
                POINT point;
                GetCursorPos(&point);

                drawList->AddLine(ImVec2(point.x, point.y), ImVec2(head2D.x, head2D.y), IM_COL32(0, 0, 0, 200), 2.5f);
                drawList->AddLine(ImVec2(point.x, point.y), ImVec2(head2D.x, head2D.y), color, 1.5f);
                break;
            case 3: 
                drawList->AddLine(ImVec2(localTorsoPos2D.x, localTorsoPos2D.y), ImVec2(head2D.x, head2D.y), IM_COL32(0, 0, 0, 200), 2.5f);
                drawList->AddLine(ImVec2(localTorsoPos2D.x, localTorsoPos2D.y), ImVec2(head2D.x, head2D.y), color, 1.5f);
                break;
            }
        }

        if (Options::ESP::Skeleton)
        {
            float newY = WorldToScreen(torso3D + Vectors::Vector3{ 0.f, 0.3f, 0.f }).y; 

            
            drawList->AddLine({ torso2D.x, newY }, ImVec2(head2D.x, head2D.y), IM_COL32(0, 0, 0, 200), 2.5f);
            drawList->AddLine({ torso2D.x, newY }, ImVec2(head2D.x, head2D.y), color, 1.5f);

            drawList->AddLine({ torso2D.x, newY }, ImVec2(lArm2D.x, lArm2D.y), IM_COL32(0, 0, 0, 200), 2.5f);
            drawList->AddLine({ torso2D.x, newY }, ImVec2(lArm2D.x, lArm2D.y), color, 1.5f);

            drawList->AddLine({ torso2D.x, newY }, ImVec2(rArm2D.x, rArm2D.y), IM_COL32(0, 0, 0, 200), 2.5f);
            drawList->AddLine({ torso2D.x, newY }, ImVec2(rArm2D.x, rArm2D.y), color, 1.5f);

            drawList->AddLine({ torso2D.x, newY }, ImVec2(lLeg2D.x, lLeg2D.y), IM_COL32(0, 0, 0, 200), 2.5f);
            drawList->AddLine({ torso2D.x, newY }, ImVec2(lLeg2D.x, lLeg2D.y), color, 1.5f);

            drawList->AddLine({ torso2D.x, newY }, ImVec2(rLeg2D.x, rLeg2D.y), IM_COL32(0, 0, 0, 200), 2.5f);
            drawList->AddLine({ torso2D.x, newY }, ImVec2(rLeg2D.x, rLeg2D.y), color, 1.5f);
        }

        if (Options::ESP::Name)
        {
            const std::string& nameStr = player.Name;
            float fontSize = 9.f * scale; 
            ImVec2 textSize = font->CalcTextSizeA(fontSize, FLT_MAX, 0.f, nameStr.c_str());

            ImVec2 namePos(newHeadName.x - textSize.x / 2.0f, newHeadName.y);
            drawList->AddText(font, fontSize, namePos, color, nameStr.c_str());
        }

        if (Options::ESP::Distance)
        {
            std::string distStr = std::to_string(roundedDistance) + " studs";
            float fontSize = 7.5f * scale; 
            ImVec2 textSize = font->CalcTextSizeA(fontSize, FLT_MAX, 0.f, distStr.c_str());

            ImVec2 distPos(head2D.x - textSize.x / 2.0f, bottom + 5);
            drawList->AddText(font, fontSize, distPos, color, distStr.c_str());
        }

        if (Options::ESP::Health)
        {
            float healthPercent = std::clamp(player.Health / player.MaxHealth, 0.f, 1.f);

            float barWidth = std::clamp(scale * 3.f, 2.f, 4.f); 
            float boxHeight = bottom - top;

            ImVec2 barTopLeft(left - barWidth - 3.f, top); 
            ImVec2 barBottomRight(left - 3.f, top + boxHeight);

            drawList->AddRectFilled(barTopLeft, barBottomRight, IM_COL32(20, 20, 20, 180)); 

            float filledHeight = boxHeight * healthPercent;
            ImVec2 filledTopLeft(barTopLeft.x, barBottomRight.y - filledHeight);
            ImVec2 filledBottomRight(barBottomRight.x, barBottomRight.y);

           
            ImU32 healthColor;
            if (healthPercent > 0.7f) {
                healthColor = IM_COL32(0, 255, 0, 220); 
            }
            else if (healthPercent > 0.3f) {
                healthColor = IM_COL32(255, 255, 0, 220);
            }
            else {
                healthColor = IM_COL32(255, 0, 0, 220); 
            }

            drawList->AddRectFilled(filledTopLeft, filledBottomRight, healthColor);

            drawList->AddRect(barTopLeft, barBottomRight, IM_COL32(0, 0, 0, 255), 0, 0, 1.0f); 
        }
    }
}