#pragma once
#include "SDK/SDK.h"

namespace Options
{
    namespace ESP
    {
        inline bool TeamCheck;
        inline bool Box;
        inline bool Tracers;
        inline int TracersStart;
        inline bool Skeleton;
        inline bool Name;
        inline bool Distance;
        inline bool Health;

        inline float Color[3];
        inline float FillColor[4];
    }

    namespace Aimbot
    {
		inline int AimbotKey = VK_RBUTTON;
		inline int AimingType;

		inline int ToggleType;

		inline bool Aimbot;
		inline bool TeamCheck;
		inline bool DownedCheck;
		inline bool StickyAim;
		inline float FOV;
		inline float Smoothness;
		inline bool ShowFOV;
		inline float Range = 100.f;

		inline float FOVColor[3];
		inline float FOVFillColor[4];

		inline int TargetBone = 0;

		inline RobloxPlayer CurrentTarget;
		inline bool Toggled;
    }

    
  
    }
