﻿#include <iostream>
#include <thread>
#include <sstream>
#include <iomanip>
#include <windows.h>
#include <string>
#include <vector>
#include <random>
#include <ctime>
#include <algorithm>

#include "Memory/MemoryManager.h"
#include "Utils/colors.h"
#include "Utils/console.h"
#include "Renderer/renderer.h"
#include "Caches/playercache.h"
#include "Caches/playerobjectscache.h"
#include "globals.h"
#include "oxorany.h"
#include "main.h"

bool IsGameRunning(const wchar_t* windowTitle) {
    HWND hwnd = FindWindowW(NULL, windowTitle);
    return hwnd != NULL;
}

void printBanner() {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_BLUE | FOREGROUND_INTENSITY);
    std::cout << R"(
add your ascii art
)" << "\n";

    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_BLUE | FOREGROUND_INTENSITY);
    std::cout << " [ wtv ]\n";
    std::cout << " [ add like version or wtv ]\n\n";

    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_BLUE | FOREGROUND_GREEN | FOREGROUND_BLUE);
}

//makes the name of the console title be random
void RandomTitleThread() {
    std::mt19937 rng((unsigned int)time(0));
    std::string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789*#%@!";

    while (true) {
        std::string title;
        int len = 8 + (rng() % 8);
        for (int i = 0; i < len; i++)
            title += chars[rng() % chars.size()];

        SetConsoleTitleA(title.c_str());
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
}

//loading animation does ======= delete if u want
void ShowLoadingScreen() {
    const int totalSteps = 36;
    int durationMs = 5000;
    int stepDelay = durationMs / totalSteps;

    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    GetConsoleScreenBufferInfo(hConsole, &csbi);
    int consoleWidth = csbi.srWindow.Right - csbi.srWindow.Left + 1;

    std::string title = "Initializing...";
    int titlePadding = (consoleWidth - title.size()) / 2;

    SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_INTENSITY);
    std::cout << std::string(titlePadding, ' ') << title << "\n\n";

    SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_INTENSITY);
    for (int i = 0; i <= totalSteps; ++i) {
        int percent = (i * 100) / totalSteps;
        std::string bar = "[";
        bar += std::string(i, '=');
        bar += std::string(totalSteps - i, ' ');
        bar += "] " + std::to_string(percent) + "%";

        int barPadding = (consoleWidth - bar.size()) / 2;
        std::cout << "\r" << std::string(barPadding, ' ') << bar;
        std::cout.flush();

        std::this_thread::sleep_for(std::chrono::milliseconds(stepDelay));
    }

    SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
    int barPadding = (consoleWidth - totalSteps - 6) / 2;
    std::cout << "\r" << std::string(barPadding, ' ') << "[" << std::string(totalSteps, '=') << "] 100%\n\n";

    SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
}

//u can remove [DEBUG] if u want    
void InjectRoutine() {
    while (!IsGameRunning(L"Roblox")) {
        log(oxorany("[DEBUG] Roblox not found!"), 2);
        log(oxorany("[DEBUG] Waiting for Roblox..."), 0);
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }

    log(oxorany("[DEBUG] Roblox found!"), 1);
    log(oxorany("[DEBUG] Attaching to Roblox..."), 0);

    if (!Memory->attachToProcess(oxorany("RobloxPlayerBeta.exe"))) {
        log(oxorany("[DEBUG] Failed to attach to Roblox!"), 2);
        return;
    }
    log(oxorany("[DEBUG] Successfully attached!"), 1);

    log(std::string(oxorany("[DEBUG] Roblox PID -> ") + std::to_string(Memory->getProcessId())), 1);

    auto fakeDataModel = Memory->read<uintptr_t>(Memory->getBaseAddress() + offsets::FakeDataModelPointer);
    Globals::Roblox::DataModel = RobloxInstance(Memory->read<uintptr_t>(fakeDataModel + offsets::FakeDataModelToDataModel));
    Globals::Roblox::VisualEngine = Memory->read<uintptr_t>(Memory->getBaseAddress() + offsets::VisualEnginePointer);
    Globals::Roblox::Workspace = Globals::Roblox::DataModel.FindFirstChildWhichIsA(oxorany("Workspace"));
    Globals::Roblox::Players = Globals::Roblox::DataModel.FindFirstChildWhichIsA(oxorany("Players"));
    Globals::Roblox::Camera = Globals::Roblox::Workspace.FindFirstChildWhichIsA(oxorany("Camera"));
    Globals::Roblox::LocalPlayer = RobloxInstance(Memory->read<uintptr_t>(Globals::Roblox::Players.address + offsets::LocalPlayer));

    std::thread(ShowImgui).detach();
    std::thread(CachePlayers).detach();
    std::thread(CachePlayerObjects).detach();
}

int main() {
    std::thread(RandomTitleThread).detach();
    ShowLoadingScreen();

    system("cls");
    printBanner();

    while (true) {
        system("cls");
        printBanner();
        std::cout << "[1] Inject\n[2] Exit\nChoose option: ";
        std::string choice;
        std::getline(std::cin, choice);

        if (choice == "1") {
            InjectRoutine();
            std::cout << "\nPress Enter to return to menu...";
            std::cin.get();
        }
        else if (choice == "2") {
            std::cout << "\nExiting...\n";
            break;
        }
        else {
            std::cout << "\nInvalid option!\n";
            Sleep(1000);
        }
    }
    return 0;
}
