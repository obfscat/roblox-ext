#pragma once
#include "imgui.h"
#include <Windows.h>
#include <string>

namespace KeyBind
{
    inline bool Listening = false;
    inline int CurrentBind = 0;

    inline const char* GetKeyName(int vk)
    {
        static char name[128] = {};
        if (vk == 0) return "None";

        switch (vk) {
        case VK_LBUTTON: return "Mouse Left";
        case VK_RBUTTON: return "Mouse Right";
        case VK_MBUTTON: return "Mouse Middle";
        case VK_XBUTTON1: return "Mouse X1";
        case VK_XBUTTON2: return "Mouse X2";
        default: break;
        }

        UINT scanCode = MapVirtualKeyA(vk, MAPVK_VK_TO_VSC);
        if (scanCode == 0) return "Unknown";

        GetKeyNameTextA(scanCode << 16, name, sizeof(name));
        return name;
    }

    inline bool KeyBindButton(const char* label, int* key)
    {
        ImGui::PushID(label);
        ImGui::PushStyleColor(ImGuiCol_Button, Listening ? ImVec4(0.9f, 0.2f, 0.2f, 1.f) : ImGui::GetStyle().Colors[ImGuiCol_Button]);

        std::string btnText = Listening ? "Press a key..." : GetKeyName(*key);
        if (ImGui::Button(btnText.c_str(), ImVec2(100, 0)))
        {
            Listening = !Listening;
            CurrentBind = *key;
        }

        ImGui::PopStyleColor();
        ImGui::PopID();

        if (Listening)
        {
            const int mouseButtons[] = { VK_LBUTTON, VK_RBUTTON, VK_MBUTTON, VK_XBUTTON1, VK_XBUTTON2 }; // black mouse key //UDUDUD
            for (int btn : mouseButtons) {
                if (GetAsyncKeyState(btn) & 0x8000) {
                    *key = btn;
                    Listening = false;
                    return true;
                }
            }

            for (int i = 1; i < 256; ++i)
            {
                if (i == VK_LBUTTON || i == VK_RBUTTON || i == VK_MBUTTON || i == VK_XBUTTON1 || i == VK_XBUTTON2)
                    continue;

                if (GetAsyncKeyState(i) & 0x8000)
                {
                    *key = i;
                    Listening = false;
                    return true;
                }
            }
        }

        return false;
    }

    inline bool IsPressed(int key)
    {
        if (key <= 0 || key >= 256)
            return false;

        return (GetAsyncKeyState(key) & 0x8000);
    }
}